import React, { Component } from "react";
import { Button, View, Text } from "react-native";

export default function ChatScreen() {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>Chat Screen</Text>
    </View>
  );
}