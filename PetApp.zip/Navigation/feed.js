import React, { Component, useState } from "react";
import { Button, View, Text,FlatList,StyleSheet,Modal,TouchableOpacity } from "react-native";
//import auth , {firebase} from '@react-native-firebase';
import { globalStyles } from "../globalStyles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import AddFeedScreen from "./add Feed";

export default function FeedScreen(props,navigation) {

  const [blogs,setBlogs]=useState([])
  const [modelOpen,setModelOpen]=useState(false)
  const [selectedCard,setSelectedCardId]=useState([])

  return (
    <View>
       <Modal
      
         visible={modelOpen}
         animationType='fade'
         transparent={true}
      > 
       </Modal> 
        <View style={styles.header}>
          <Text style={globalStyles.headingText}>My Feeds</Text>
        </View>

        <View >
        <TouchableOpacity
                onPress={() => {
                    props.navigation.navigate("AddFeedScreen")
                }}>
            <Ionicons style={styles.addIcon}
               name='add-circle-sharp'
               size={54}
               color='black'
              
            />
            </TouchableOpacity>
         </View>
     
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
     marginHorizontal: 10,
     marginVertical: 10
  },
  addIcon: {
     position: 'absolute',
    right:10,
    top:80,
   //bottom:'20%',
   // backgroundColor:'black',
     borderRadius:30,
     //left: '45%',
     zIndex:1,
     elevation: 20,
     margin:20,
  }
})